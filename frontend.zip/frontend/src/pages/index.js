// THIS JS IS SERVING AS AN EXPORT COMPONENT FOR BOTH CREATEPOST AND HOME.JSX AS A SINGLE OBJECT COMPONENT 

import Home from './Home';
import CreatePost from './CreatePost';

export  {
     Home,
     CreatePost,
};
